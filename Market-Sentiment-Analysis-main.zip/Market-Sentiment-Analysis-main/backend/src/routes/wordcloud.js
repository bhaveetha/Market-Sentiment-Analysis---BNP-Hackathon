// src/routes/wordcloud.js
const express = require("express");
const Article = require("../models/Article");
const r = express.Router();

/* ------------ helpers ------------ */
const STOP = new Set([
  "the","and","has", "have", "one" , "why" , "next", "out", "now" ,"how","what","when","where","which", "for","with","that","from","this","into","will","would","could","should",
  "about","over","amid","after","before","as","by","to","of","on","in","at","vs","via",
  "is","are","was","were","be","been","being","it","its","their","his","her","they","we","you",
  "a","an","or","but","if","than","then","not","no","yes","new","more","less",
  "earnings","results","update","breaking","news","report","reports","reported",
  "stock","stocks","share","shares","company","companies","corp","inc","plc","ltd","co",
  "quarter","q1","q2","q3","q4","fy","2022","2023","2024","2025",
  "ceo","cfo","cto","chief","officer","board","press","release",
  "today","yesterday","tomorrow","week","month","year","day",
  "price","target","pt","downgrade","upgrade","initiates","initiated","initiating",
  "buy","sell","hold","strong","neutral",
  "u","us","usa","com"
]);

const winToDays = (w) => {
  const t = String(w || "").toLowerCase();
  if (t === "3d") return 3;
  if (t === "7d") return 7;
  if (t === "30d") return 30;
  if (t === "1y") return 365;
  return null;
};

function sinceFromQuery(q) {
  let days = parseInt(q.days, 10);
  if (!Number.isFinite(days) || days <= 0) {
    const d = winToDays(q.window);
    days = d || 15; // default: last 15 days
  }
  return new Date(Date.now() - days * 24 * 3600 * 1000);
}

// crude variants for filtering a brand token (singular/plural/possessive)
function brandVariants(w) {
  const base = String(w || "").toLowerCase();
  const s = new Set([base]);
  s.add(base.replace(/'s$/i, ""));  // remove possessive
  s.add(base + "s");                // plural
  // simple endings
  if (base.endsWith("ies")) s.add(base.slice(0, -3) + "y");
  if (base.endsWith("es")) s.add(base.slice(0, -2));
  if (base.endsWith("s")) s.add(base.slice(0, -1));
  return s;
}

// find frequent Proper Nouns (Capitalized) in original text to exclude brand words
function collectBrandCandidates(rows) {
  const capsCount = {};
  for (const x of rows) {
    const raw = `${x.title || ""} ${x.summary || ""}`;
    // single capitalized words, length >= 3
    const singles = raw.match(/\b[A-Z][a-z]{2,}\b/g) || [];
    for (const w of singles) {
      const k = w.toLowerCase();
      capsCount[k] = (capsCount[k] || 0) + 1;
    }
    // Multi-word Proper Noun sequences -> split to words and count
    const multi = raw.match(/\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b/g) || [];
    for (const phrase of multi) {
      const parts = phrase.split(/\s+/).map(s => s.toLowerCase());
      for (const p of parts) {
        if (p.length >= 3) capsCount[p] = (capsCount[p] || 0) + 1;
      }
    }
  }
  const top = Object.entries(capsCount)
    .sort((a,b)=>b[1]-a[1])
    .slice(0, 4)               // a few top proper-noun tokens
    .map(([w]) => w);
  return new Set(top);
}

/* ------------ route ------------ */
r.get("/:symbol", async (req, res) => {
  try {
    const symbol = String(req.params.symbol || "").toUpperCase();
    const since = sinceFromQuery(req.query);
    const topK = Math.max(15, Math.min(parseInt(req.query.top, 10) || 18, 80)); // default 18, min 15

    // pull recent articles for this symbol in the window
    const rows = await Article.find({
      symbol,
      publishedAt: { $gte: since }
    })
      .sort({ publishedAt: -1 })
      .limit(1000)   // enough to build a good cloud
      .lean();

    // build exclusion set: ticker + optional name query + brand candidates from text
    const EXCLUDE = new Set();
    EXCLUDE.add(symbol.toLowerCase());            // "amzn"
    EXCLUDE.add(symbol);                          // "AMZN"

    // optional `?name=Amazon` (frontend may send later if you wish)
    const qName = String(req.query.name || "").trim();
    if (qName) {
      for (const v of brandVariants(qName)) EXCLUDE.add(v);
    }

    // detect proper-noun brand words from headlines/summaries
    const brandTokens = collectBrandCandidates(rows);
    for (const w of brandTokens) for (const v of brandVariants(w)) EXCLUDE.add(v);

    // count tokens
    const counts = {};
    for (const x of rows) {
      const raw = `${x.title || ""} ${x.summary || ""}`;
      // lowercase tokens, letters only (len >= 3 to keep things like "meta", "tesla", "ai" excluded)
      const words = (raw.toLowerCase().match(/[a-z]{3,}/g) || []);
      for (let w of words) {
        if (STOP.has(w)) continue;
        if (EXCLUDE.has(w)) continue;
        counts[w] = (counts[w] || 0) + 1;
      }
    }

    // top terms
    let terms = Object.entries(counts)
      .sort((a,b)=>b[1]-a[1])
      .slice(0, topK)
      .map(([text, count]) => ({ text, count }));

    res.json({ words: terms, days: Math.round((Date.now()-since.getTime())/(24*3600*1000)) });
  } catch (e) {
    console.error("wordcloud error", e);
    res.status(500).json({ error: e.message || "failed to build wordcloud" });
  }
});

module.exports = r;
