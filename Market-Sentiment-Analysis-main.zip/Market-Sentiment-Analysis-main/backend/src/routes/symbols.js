const express = require("express");
const SymbolModel = require("../models/Symbol");
const { listSymbols } = require("../services/finnhub");

const r = express.Router();

// Sync Finnhub symbols into Mongo (per exchange, e.g. US/IN/etc.)
r.post("/sync", async (req, res) => {
  const exchange = (req.query.exchange || "US").toUpperCase();
  const rows = await listSymbols(exchange);
  if (!Array.isArray(rows) || !rows.length) {
    return res.status(500).json({ ok: false, error: "Empty symbols list from Finnhub" });
  }
  const ops = rows.map(x => ({
    updateOne: {
      filter: { symbol: (x.symbol || "").toUpperCase().trim() },
      update: {
        $set: {
          display: x.description || "",
          currency: x.currency || "",
          mic: x.mic || "",
          type: x.type || "",
          exchange,
          updatedAt: new Date(),
        }
      },
      upsert: true
    }
  }));
  await SymbolModel.bulkWrite(ops, { ordered: false });
  const count = await SymbolModel.countDocuments({ exchange });
  res.json({ ok: true, exchange, stored: count });
});

// Search symbols by ticker or name
r.get("/", async (req, res) => {
  const { q, symbol, exchange } = req.query;

  if (symbol) {
    const row = await SymbolModel.findOne({ symbol: String(symbol).toUpperCase().trim() }).lean();
    return res.json({ items: row ? [row] : [] });
  }

  if (!q) {
    const filter = exchange ? { exchange: String(exchange).toUpperCase() } : {};
    const items = await SymbolModel.find(filter).sort({ symbol: 1 }).limit(50).lean();
    return res.json({ items });
  }

  const needle = String(q).trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regex = new RegExp(needle, "i");
  const filter = exchange ? { exchange: String(exchange).toUpperCase() } : {};

  const items = await SymbolModel
    .find({ ...filter, $or: [{ symbol: regex }, { display: regex }] })
    .sort({ symbol: 1 })
    .limit(25)
    .lean();

  res.json({ items });
});

module.exports = r;
