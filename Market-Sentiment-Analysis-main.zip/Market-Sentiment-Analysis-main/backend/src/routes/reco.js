const express = require("express");
const Aggregate = require("../models/Aggregate");
const r = express.Router();
r.get("/:symbol", async (req,res)=>{
  const a = await Aggregate.findOne({ symbol:req.params.symbol, window:"7d" });
  const subs = a?.subs || { news:0,social:0,macro:0 };
  const trend = a?.sparkline || [0,0];
  const base = 0.5*subs.news + 0.3*subs.social + 0.2*subs.macro;
  const mom = trend.length>1 ? (trend[trend.length-1]-trend[0]) : 0;
  const score = base + 0.2*mom;
  const stance = score>0.25 ? "Buy" : score<-0.25 ? "Sell" : "Hold";
  res.json({ stance, rationale:`News/Social/Macro=${base.toFixed(2)}, momentum=${mom.toFixed(2)}` });
});
module.exports = r;
