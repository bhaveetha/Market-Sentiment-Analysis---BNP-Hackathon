const express = require("express");
const Aggregate = require("../models/Aggregate");
const r = express.Router();
r.get("/:symbol", async (req,res)=>{
  const window = String(req.query.window||"7d");
  const doc = await Aggregate.findOne({ symbol:req.params.symbol, window }) || {
    score0to5:0, subs:{news:0,social:0,macro:0}, sparkline:[], updatedAt:null
  };
  res.json(doc);
});
module.exports = r;
