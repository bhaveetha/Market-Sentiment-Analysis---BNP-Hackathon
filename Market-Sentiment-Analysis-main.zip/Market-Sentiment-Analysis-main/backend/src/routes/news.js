// src/routes/news.js
const express = require("express");
const Article = require("../models/Article");

const r = express.Router();

const daysMap = { "7d": 7, "30d": 30, "1y": 365 };

r.get("/:symbol", async (req, res) => {
  try {
    const symbol = String(req.params.symbol || "").toUpperCase();
    const window = String(req.query.window || "7d").toLowerCase();
    const days = daysMap[window] || 7;
    const since = new Date(Date.now() - days * 24 * 3600 * 1000);

    // optional pagination
    const page = Math.max(1, parseInt(req.query.page || "1", 10));
    const pageSize = Math.min(100, Math.max(1, parseInt(req.query.pageSize || "50", 10)));
    const skip = (page - 1) * pageSize;

    const [items, total] = await Promise.all([
      Article.find({ symbol, publishedAt: { $gte: since } })
        .sort({ publishedAt: -1 })
        .skip(skip)
        .limit(pageSize)
        .lean(),
      Article.countDocuments({ symbol, publishedAt: { $gte: since } })
    ]);

    res.json({
      items: items.map(a => ({
        id: a._id,
        source: a.source,
        title: a.title,
        summary: a.summary,
        url: a.url,
        image: a.image,
        publishedAt: a.publishedAt,
        score: a.score,
        why: a.phrases
      })),
      page,
      pageSize,
      total,
      hasMore: skip + items.length < total
    });
  } catch (e) {
    console.error("news route error", e);
    res.status(500).json({ items: [], error: e.message || "unknown error" });
  }
});

module.exports = r;
