// src/routes/overview.js
const express = require("express");
const Article = require("../models/Article");
const Aggregate = require("../models/Aggregate");

let Watch = null; // optional; falls back to .env WATCHLIST
try { Watch = require("../models/Watch"); } catch {}

const r = express.Router();

// label thresholds for headline sentiment
const POS = 0.05, NEG = -0.05;

// tweakable via .env
const BUY_THR  = parseFloat(process.env.BUY_THR  ?? "0.08");
const SELL_THR = parseFloat(process.env.SELL_THR ?? "-0.08");

// map canonical windows to days
const winToDays = (w) => {
  const t = String(w || "").toLowerCase();
  if (t === "3d")  return 3;
  if (t === "7d")  return 7;
  if (t === "30d") return 30;
  if (t === "1y")  return 365;
  return null;
};
// choose an Aggregate.window bucket given a days span
const bucketForDays = (d) => (d <= 7 ? "7d" : d <= 30 ? "30d" : "1y");
// pretty label for UI
const labelForDays = (d) =>
  (d === 3 ? "3d" : d === 7 ? "7d" : d === 30 ? "30d" : d === 365 ? "1y" : `${d}d`);

/* ---------------- helpers ---------------- */
function stanceFrom(subs = { news:0,social:0,macro:0 }, spark = []) {
  const base = 0.5*(subs.news||0) + 0.3*(subs.social||0) + 0.2*(subs.macro||0);
  const mom  = spark.length > 1 ? (spark[spark.length-1] - spark[0]) : 0;
  const s = base + 0.2*mom;
  return s > 0.25 ? "Buy" : s < -0.25 ? "Sell" : "Hold";
}
function linSlope(arr = []) {
  const n = arr.length; if (n < 2) return 0;
  let sx=0, sy=0, sxy=0, sxx=0;
  for (let i=0;i<n;i++){ const y = +arr[i] || 0; sx+=i; sy+=y; sxy+=i*y; sxx+=i*i; }
  const d = n*sxx - sx*sx; return d ? (n*sxy - sx*sy)/d : 0;
}
function effectiveSlope(slopePerDay, counts){
  const total = Math.max(1, counts?.total || 0);
  const breadth = ((counts?.pos||0) - (counts?.neg||0)) / total; // -1..+1
  return 0.8*slopePerDay + 0.02*breadth;
}
function predictDays(newsNow, slopePerDay, counts, buyThr=BUY_THR, sellThr=SELL_THR){
  const m = effectiveSlope(slopePerDay, counts);
  let buyIn=null, sellIn=null;
  if (m > 1e-6 && newsNow < buyThr) {
    const d = (buyThr - newsNow)/m; buyIn = Number.isFinite(d)&&d>0 ? Math.ceil(Math.min(d,120)) : null;
  }
  if (m < -1e-6 && newsNow > sellThr) {
    const d = (newsNow - sellThr)/Math.abs(m); sellIn = Number.isFinite(d)&&d>0 ? Math.ceil(Math.min(d,120)) : null;
  }
  return { buyInDays: buyIn, sellInDays: sellIn, slopePerDay: m };
}

/* ---------------- route ---------------- */
r.get("/", async (req, res) => {
  try {
    // --------- symbol universe ---------
    const hasSymbolsParam = !!req.query.symbols;
    const symbols = hasSymbolsParam
      ? String(req.query.symbols)
          .split(/[,\s]+/)
          .map(s=>s.trim().toUpperCase())
          .filter(Boolean)
      : await (async () => {
          if (Watch) {
            const rows = await Watch.find().lean().catch(()=>[]);
            if (rows?.length) return rows.map(r => r.symbol);
          }
          return (process.env.WATCHLIST || "AAPL,MSFT,NVDA,GOOGL,AMZN")
            .split(",")
            .map(s=>s.trim().toUpperCase())
            .filter(Boolean);
        })();

    // --------- window / days ---------
    // Accept either window=3d|7d|30d|1y OR days=<number>
    const reqWindow = req.query.window;
    const fromWin = winToDays(reqWindow);
    let days = parseInt(req.query.days, 10);
    if (!Number.isFinite(days) || days <= 0) days = fromWin ?? (hasSymbolsParam ? 365 : 3);
    const since = new Date(Date.now() - days*24*3600*1000);
    const windowBucket = bucketForDays(days);
    const windowLabel  = labelForDays(days); // for UI header

    // --------- sorting & limits ---------
    const direction = (req.query.direction || "pos").toLowerCase(); // "pos" | "neg"
    const limit = hasSymbolsParam ? 0 : Math.max(1, Math.min(parseInt(req.query.limit, 10) || 5, 100));

    // feed behavior:
    //   - Home (no symbols): feed=all, feedLimit=15 (default)
    //   - Search (symbols):  feed=selected, feedLimit=20 (default)
    const explicitFeedLimit = Object.prototype.hasOwnProperty.call(req.query, "feedLimit")
      ? Math.max(0, parseInt(req.query.feedLimit, 10) || 0)
      : null;

    const feedMode  = (req.query.feed || (hasSymbolsParam ? "selected" : "all")).toLowerCase(); // "selected"|"all"
    const feedLimit = explicitFeedLimit ?? (hasSymbolsParam ? 20 : 15); // <-- key change

    // --------- pull articles (window-constrained) ---------
    const articles = await Article
      .find({ symbol: { $in: symbols }, publishedAt: { $gte: since } })
      .sort({ publishedAt: -1 })
      .limit(10000)
      .lean();

    // counts + raw notifications
    const counts = {}; for (const s of symbols) counts[s] = { pos:0, neg:0, neu:0, total:0 };
    const allNotifications = articles.map(a => {
      const sc = +a.score || 0;
      const label = sc >= POS ? "Positive" : sc <= NEG ? "Negative" : "Neutral";
      const c = counts[a.symbol] || (counts[a.symbol] = { pos:0, neg:0, neu:0, total:0 });
      c.total++; if (label==="Positive") c.pos++; else if (label==="Negative") c.neg++; else c.neu++;
      return {
        symbol: a.symbol,
        id: a._id,
        title: a.title,
        url: a.url,
        source: a.source,
        publishedAt: a.publishedAt,
        score: sc,
        label
      };
    });

    // aggregates (nearest bucket)
    const aggs = await Aggregate.find({ symbol: { $in: symbols }, window: windowBucket }).lean();
    const aggMap = new Map(aggs.map(x => [x.symbol, x]));

    // rows
    const rows = symbols.map(sym => {
      const c = counts[sym] || { pos:0, neg:0, neu:0, total:0 };
      const a = aggMap.get(sym) || { score0to5:0, subs:{news:0,social:0,macro:0}, sparkline:[] };
      const newsNow = typeof a?.subs?.news === "number"
        ? a.subs.news
        : (a.sparkline?.length ? a.sparkline[a.sparkline.length-1] : 0);
      const slope  = linSlope(a.sparkline || []);
      const stance = stanceFrom(a.subs, a.sparkline);
      const pred   = predictDays(newsNow, slope, c);
      const total  = c.total || 0;
      return {
        symbol: sym,
        counts: c,
        posPct: total ? c.pos/total : 0,
        negPct: total ? c.neg/total : 0,
        score0to5: a.score0to5 || 0,
        subs: a.subs || { news:0, social:0, macro:0 },
        stance,
        pred
      };
    });

    // sort
    rows.sort((A,B) => {
      const netA = A.posPct - A.negPct;
      const netB = B.posPct - B.negPct;
      if (direction === "neg") {
        return (A.negPct - A.posPct) - (B.negPct - B.posPct) || (A.score0to5 - B.score0to5);
      }
      return (netB - netA) || (B.score0to5 - A.score0to5);
    });

    // Top-N (only when !symbols)
    const companies = limit ? rows.slice(0, limit) : rows;

    // feed set + trimming
    const selectedSet = new Set(companies.map(x => x.symbol));
    const feedSet = (feedMode === "all") ? new Set(symbols) : selectedSet;
    let notifications = allNotifications.filter(n => feedSet.has(n.symbol));
    if (feedLimit > 0) notifications = notifications.slice(0, feedLimit); // newest-first already

    // respond
    res.json({
      window: windowLabel,     // e.g., "3d" | "7d" | "30d" | "1y" | "Xd"
      days,
      direction,
      feed: feedMode,
      symbols: Array.from(selectedSet),
      companies,
      notifications
    });
  } catch (e) {
    console.error("overview error", e);
    res.status(500).json({ error: e.message || "unknown error" });
  }
});

module.exports = r;
