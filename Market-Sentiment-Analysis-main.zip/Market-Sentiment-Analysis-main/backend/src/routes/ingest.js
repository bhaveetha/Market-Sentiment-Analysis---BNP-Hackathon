// src/routes/ingest.js
const express = require("express");
const { companyNews, marketNews, companyProfile2 } = require("../services/finnhub");
const { normalizeArticles, mapToFive } = require("../utils/normalize");
const { scoreText } = require("../services/sentiment");
const Article = require("../models/Article");
const { buildAndSaveAllWindows } = require("../services/agg");

const r = express.Router();

/**
 * Manually ingest and score news for a symbol.
 * Example:
 *   GET /api/ingest/AAPL            -> defaults to 30 days
 *   GET /api/ingest/NVDA?days=365   -> full year
 *   GET /api/ingest/TSLA?days=30&cats=general,merger
 */
r.get("/:symbol", async (req, res) => {
  try {
    const symbol = String(req.params.symbol || "").toUpperCase();
    const days = Math.max(1, Math.min(365, Number(req.query.days || 30)));
    const to = new Date();
    const from = new Date(Date.now() - days * 24 * 3600 * 1000);
    const iso = (d) => d.toISOString().slice(0, 10);

    // 1) Try company-specific news first
    let items = await companyNews(symbol, iso(from), iso(to));

    // 2) Fallback: Market News filtered by company name/ticker (helps for non-US tickers)
    if (!items || items.length === 0) {
      const profile = await companyProfile2(symbol);
      const name = (profile.name || symbol).toLowerCase();
      const categories = (req.query.cats ? String(req.query.cats).split(",") : ["general", "merger"]).map(s => s.trim());
      const feeds = await Promise.all(categories.map(c => marketNews(c)));
      const merged = feeds.flat();
      items = merged.filter(a => {
        const text = `${a.headline || a.title || ""} ${a.summary || ""}`.toLowerCase();
        return text.includes(name) || text.includes(symbol.toLowerCase());
      });
    }

    // 3) Normalize, score, upsert into Mongo
    const norm = normalizeArticles(items || [], symbol);
    let upserts = 0;
    for (const a of norm) {
      const { score, phrases } = scoreText(a.title, a.summary);
      await Article.updateOne({ _id: a._id }, { ...a, score, phrases }, { upsert: true });
      upserts++;
    }

    // 4) Build & save aggregates for 7d, 30d, 1y
    await buildAndSaveAllWindows(symbol, mapToFive);

    res.json({ ok: true, symbol, days, articles_processed: upserts });
  } catch (e) {
    console.error("ingest error", e);
    res.status(500).json({ ok: false, error: e.message || "unknown error" });
  }
});

module.exports = r;
