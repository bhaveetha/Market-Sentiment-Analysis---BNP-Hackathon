const express = require("express");
const Article = require("../models/Article");
const Aggregate = require("../models/Aggregate");

const r = express.Router();
const daysMap = { "7d": 7, "30d": 30, "1y": 365 };
const POS = 0.05, NEG = -0.05;

// same helpers you already use
function stanceFrom(subs = { news:0,social:0,macro:0 }, spark = []) {
  const base = 0.5*(subs.news||0) + 0.3*(subs.social||0) + 0.2*(subs.macro||0);
  const mom = spark.length > 1 ? (spark[spark.length-1] - spark[0]) : 0;
  const s = base + 0.2*mom;
  return s > 0.25 ? "Buy" : s < -0.25 ? "Sell" : "Hold";
}
function linSlope(arr = []) {
  const n = arr.length; if (n < 2) return 0;
  let sx=0, sy=0, sxy=0, sxx=0;
  for (let i=0;i<n;i++){ const y=+arr[i]||0; sx+=i; sy+=y; sxy+=i*y; sxx+=i*i; }
  const d = n*sxx - sx*sx; return d ? (n*sxy - sx*sy)/d : 0;
}
function effectiveSlope(m, counts) {
  const total = Math.max(1, counts?.total||0);
  const breadth = ((counts?.pos||0)-(counts?.neg||0))/total;
  return 0.8*m + 0.02*breadth;
}
function predictDays(newsNow, slopePerDay, counts, buyThr=0.08, sellThr=-0.08){
  const m = effectiveSlope(slopePerDay, counts);
  let buyIn=null, sellIn=null;
  if (m > 1e-6 && newsNow < buyThr) {
    const d = (buyThr-newsNow)/m; buyIn = Number.isFinite(d)&&d>0 ? Math.ceil(Math.min(d,120)) : null;
  }
  if (m < -1e-6 && newsNow > sellThr) {
    const d = (newsNow-sellThr)/Math.abs(m); sellIn = Number.isFinite(d)&&d>0 ? Math.ceil(Math.min(d,120)) : null;
  }
  return { buyInDays: buyIn, sellInDays: sellIn, slopePerDay: m };
}

async function computeTopN(window="7d", limit=5) {
  const days = daysMap[window] || 7;
  const since = new Date(Date.now() - days*24*3600*1000);

  // all symbols that have data in window
  const universe = await Article.distinct("symbol", { publishedAt: { $gte: since } });

  // pull articles (for notifications + counts)
  const articles = await Article
    .find({ symbol: { $in: universe }, publishedAt: { $gte: since } })
    .sort({ publishedAt: -1 })
    .limit(8000)
    .lean();

  const counts = {}; for (const s of universe) counts[s] = { pos:0, neg:0, neu:0, total:0 };
  const notifications = [];
  for (const a of articles) {
    const sc = +a.score || 0;
    const label = sc>=POS ? "Positive" : sc<=NEG ? "Negative" : "Neutral";
    const c = counts[a.symbol] || (counts[a.symbol] = {pos:0,neg:0,neu:0,total:0});
    c.total++; if (label==="Positive") c.pos++; else if (label==="Negative") c.neg++; else c.neu++;
    notifications.push({
      symbol:a.symbol, id:a._id, title:a.title, url:a.url, source:a.source,
      publishedAt:a.publishedAt, score:sc, label
    });
  }

  // aggregates for stance + momentum
  const aggs = await Aggregate.find({ symbol:{ $in: universe }, window }).lean();
  const aggMap = new Map(aggs.map(x => [x.symbol, x]));

  const rows = universe.map(sym => {
    const c = counts[sym] || { pos:0,neg:0,neu:0,total:0 };
    const a = aggMap.get(sym) || { score0to5:0, subs:{news:0,social:0,macro:0}, sparkline:[] };
    const newsNow = typeof a?.subs?.news === "number"
      ? a.subs.news
      : (a.sparkline?.length ? a.sparkline[a.sparkline.length-1] : 0);
    const slope = linSlope(a.sparkline || []);
    const stance = stanceFrom(a.subs, a.sparkline);
    const pred = predictDays(newsNow, slope, c);
    const total = c.total || 0;
    return {
      symbol: sym,
      counts: c,
      posPct: total ? c.pos/total : 0,
      negPct: total ? c.neg/total : 0,
      score0to5: a.score0to5 || 0,
      subs: a.subs || { news:0, social:0, macro:0 },
      stance, pred
    };
  });

  rows.sort((A,B)=>
    (B.posPct - B.negPct) - (A.posPct - A.negPct) || (B.score0to5 - A.score0to5)
  );

  const companies = rows.filter(c => c.counts.total>0 || (c.score0to5 ?? 0)!==0)
                        .slice(0, limit);

  const included = new Set(companies.map(c => c.symbol));
  const notifFiltered = notifications.filter(n => included.has(n.symbol));

  return { window, companies, notifications: notifFiltered, symbols: [...included] };
}

// SSE endpoint
r.get("/top5", async (req, res) => {
  const window = String(req.query.window || "7d").toLowerCase();
  const limit  = Math.max(1, Math.min(parseInt(req.query.limit,10)||5, 10));
  const periodMs = Math.max(5000, parseInt(req.query.periodMs,10) || 15000);

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders?.();

  let alive = true;
  req.on("close", () => { alive = false; clearInterval(timer); });

  const push = async () => {
    try {
      const payload = await computeTopN(window, limit);
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
    } catch (e) {
      res.write(`event: error\ndata: ${JSON.stringify({ error: e.message })}\n\n`);
    }
  };

  // initial snapshot + interval updates
  await push();
  const timer = setInterval(() => alive && push(), periodMs);
});

module.exports = r;
