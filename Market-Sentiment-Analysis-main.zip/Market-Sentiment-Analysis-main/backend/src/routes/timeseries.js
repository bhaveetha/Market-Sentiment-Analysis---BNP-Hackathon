// src/routes/timeseries.js
const express = require("express");
const Article = require("../models/Article");

const r = express.Router();

// classify thresholds (same as overview)
const POS = 0.05, NEG = -0.05;

// map window to days (fallback: 30)
function winToDays(w) {
  const t = String(w || "").toLowerCase();
  if (t === "3d") return 3;
  if (t === "7d") return 7;
  if (t === "30d") return 30;
  if (t === "1y") return 365;
  return null;
}

r.get("/:symbol", async (req, res) => {
  try {
    const symbol = String(req.params.symbol || "").toUpperCase().trim();
    if (!symbol) return res.status(400).json({ error: "symbol required" });

    // choose number of days: ?days or ?window (3d/7d/30d/1y)
    let days = parseInt(req.query.days, 10);
    if (!Number.isFinite(days) || days <= 0) {
      const fromWin = winToDays(req.query.window);
      days = fromWin ?? 30;
    }
    const since = new Date(Date.now() - days * 24 * 3600 * 1000);

    // aggregate Articles → daily avg sentiment and counts
    const rows = await Article.aggregate([
      { $match: { symbol, publishedAt: { $gte: since } } },
      {
        $project: {
          day: { $dateToString: { format: "%Y-%m-%d", date: "$publishedAt" } },
          score: { $ifNull: ["$score", 0] },
        },
      },
      {
        $group: {
          _id: "$day",
          avgScore: { $avg: "$score" },
          pos: { $sum: { $cond: [{ $gte: ["$score", POS] }, 1, 0] } },
          neg: { $sum: { $cond: [{ $lte: ["$score", NEG] }, 1, 0] } },
          neu: {
            $sum: {
              $cond: [
                {
                  $and: [
                    { $lt: ["$score", POS] },
                    { $gt: ["$score", NEG] },
                  ],
                },
                1,
                0,
              ],
            },
          },
          total: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    // normalize to flat array
    const series = rows.map((r) => ({
      date: r._id,
      avgScore: r.avgScore,
      pos: r.pos,
      neu: r.neu,
      neg: r.neg,
      total: r.total,
    }));

    res.json({ days, symbol, series });
  } catch (e) {
    console.error("timeseries error", e);
    res.status(500).json({ error: e.message || "unknown error" });
  }
});

module.exports = r;
