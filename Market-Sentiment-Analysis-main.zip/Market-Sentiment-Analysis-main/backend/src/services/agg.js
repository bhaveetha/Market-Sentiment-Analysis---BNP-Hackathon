// src/services/agg.js
const Article = require("../models/Article");
const Aggregate = require("../models/Aggregate");

/** Map number of days to window key used in DB */
function daysToWindow(days) {
  if (days === 7) return "7d";
  if (days === 30) return "30d";
  return "1y"; // 365
}

/**
 * Compute average news sentiment and a per-day sparkline
 * over the last `days` days for a symbol.
 */
async function buildAggregate(symbol, days = 7) {
  const now = Date.now();
  const since = new Date(now - days * 24 * 3600 * 1000);

  const items = await Article
    .find({ symbol, publishedAt: { $gte: since } })
    .sort({ publishedAt: 1 })
    .lean();

  const newsAvg = items.length
    ? items.reduce((sum, x) => sum + (x.score || 0), 0) / items.length
    : 0;

  // bucket scores by calendar day
  const bucketByDay = new Map();
  for (const it of items) {
    const key = it.publishedAt.toISOString().slice(0, 10);
    const arr = bucketByDay.get(key) || [];
    arr.push(it.score || 0);
    bucketByDay.set(key, arr);
  }

  // build ordered day keys for the window
  const keys = Array.from({ length: days }, (_, i) => {
    const d = new Date(now - (days - 1 - i) * 24 * 3600 * 1000);
    return d.toISOString().slice(0, 10);
  });

  // average per day -> sparkline
  const sparkline = keys.map(k => {
    const arr = bucketByDay.get(k) || [];
    return arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
  });

  return { newsAvg, sparkline };
}

/** Upsert a single aggregate doc for (symbol, window) */
async function saveAggregate(symbol, window, payload) {
  await Aggregate.updateOne(
    { symbol, window },
    { ...payload, updatedAt: new Date() },
    { upsert: true }
  );
}

/**
 * Build and save aggregates for 7d, 30d, and 1y.
 * `mapToFive` should convert [-1,1] -> [0,5].
 */
async function buildAndSaveAllWindows(symbol, mapToFive) {
  const windows = [7, 30, 365];
  for (const days of windows) {
    const { newsAvg, sparkline } = await buildAggregate(symbol, days);
    const doc = {
      score0to5: mapToFive(newsAvg),
      subs: { news: newsAvg, social: 0, macro: 0 }, // fill social/macro later
      sparkline
    };
    await saveAggregate(symbol, daysToWindow(days), doc);
  }
}

module.exports = {
  buildAggregate,
  buildAndSaveAllWindows,
  saveAggregate,
  daysToWindow,
};
