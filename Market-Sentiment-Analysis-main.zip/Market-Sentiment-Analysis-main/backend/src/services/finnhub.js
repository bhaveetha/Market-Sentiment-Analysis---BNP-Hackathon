// src/services/finnhub.js
const axios = require("axios");

/**
 * ENV
 *  - FINNHUB_TOKEN      (required)
 *  - FINNHUB_BASEURL    (optional, default https://finnhub.io/api/v1)
 *  - FINNHUB_TIMEOUT_MS (optional, default 15000)
 *  - FINNHUB_MAX_RETRIES(optional, default 3)
 */
const baseURL = process.env.FINNHUB_BASEURL || "https://finnhub.io/api/v1";
const token   = process.env.FINNHUB_TOKEN;
const timeout = parseInt(process.env.FINNHUB_TIMEOUT_MS || "15000", 10);
const maxRetries = Math.max(0, parseInt(process.env.FINNHUB_MAX_RETRIES || "3", 10));

if (!token) {
  console.warn("[finnhub] FINNHUB_TOKEN not set. Put it in your .env");
}

const http = axios.create({
  baseURL,
  headers: { "X-Finnhub-Token": token || "" },
  timeout,
});

// --- helpers ---
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
const jitter = (ms) => Math.round(ms * (0.85 + Math.random() * 0.3)); // +/-15%

// YYYY-MM-DD guard (Finnhub expects this format for /company-news)
const toISODate = (d) => {
  const x = d instanceof Date ? d : new Date(d);
  return isNaN(+x) ? null : x.toISOString().slice(0, 10);
};

// Core GET with retry/backoff for 429/5xx
async function getJson(path, params = {}, retries = maxRetries) {
  try {
    const { data } = await http.get(path, { params });
    return data ?? null;
  } catch (e) {
    const status = e?.response?.status;
    // Retry only on rate limit or server errors
    if (retries > 0 && (status === 429 || (status >= 500 && status < 600))) {
      const retryAfterSec = Number(e?.response?.headers?.["retry-after"]);
      const baseBackoff = retryAfterSec
        ? clamp(retryAfterSec * 1000, 800, 10_000)
        : (maxRetries - retries + 1) * 1200; // 1.2s, 2.4s, 3.6s...
      const wait = jitter(baseBackoff);
      console.warn(`[finnhub] GET ${path} -> ${status}. Retrying in ~${wait}ms (${retries} left)`);
      await sleep(wait);
      return getJson(path, params, retries - 1);
    }
    const msg = e?.response?.data || e?.message || "unknown error";
    console.error(`[finnhub] GET ${path} failed:`, status, msg);
    return null;
  }
}

/* ------------------ Primary endpoints you use ------------------ */

/**
 * Company-specific news
 * @param {string} symbol e.g., "AAPL"
 * @param {string|Date} from YYYY-MM-DD or Date
 * @param {string|Date} to   YYYY-MM-DD or Date
 */
async function companyNews(symbol, from, to) {
  if (!symbol) return [];
  const f = typeof from === "string" ? from : toISODate(from);
  const t = typeof to === "string" ? to : toISODate(to);
  if (!f || !t) {
    console.warn("[finnhub] companyNews: invalid date(s)", from, to);
    return [];
  }
  const data = await getJson("/company-news", { symbol, from: f, to: t });
  return Array.isArray(data) ? data : [];
}

/**
 * Market news by category
 * @param {"general"|"forex"|"crypto"|"merger"} category
 * @param {number} [minId] for incremental paging
 */
async function marketNews(category = "general", minId) {
  const params = { category };
  if (typeof minId !== "undefined") params.minId = minId;
  const data = await getJson("/news", params);
  return Array.isArray(data) ? data : [];
}

/** Basic company profile */
async function companyProfile2(symbol) {
  if (!symbol) return {};
  return (await getJson("/stock/profile2", { symbol })) || {};
}

/** Finnhub’s own news sentiment summary (optional) */
async function newsSentiment(symbol) {
  if (!symbol) return {};
  return (await getJson("/news-sentiment", { symbol })) || {};
}

/* ------------------ Symbols & utilities ------------------ */

/**
 * Full symbol list for an exchange (e.g., US, IN, TO, XNSE, etc.)
 * TIP: call once and cache in DB (you already do via /api/symbols/sync)
 */
async function listSymbols(exchange = "US") {
  const data = await getJson("/stock/symbol", { exchange });
  return Array.isArray(data) ? data : [];
}

/** Text lookup across symbols */
async function symbolLookup(q) {
  if (!q) return { count: 0, result: [] };
  return (await getJson("/search", { q })) || { count: 0, result: [] };
}

/** Real-time quote */
async function quote(symbol) {
  if (!symbol) return {};
  return (await getJson("/quote", { symbol })) || {};
}

/**
 * Historical candles
 * @param {string} symbol
 * @param {"1"|"5"|"15"|"30"|"60"|"D"|"W"|"M"} resolution
 * @param {number} fromUnix seconds since epoch
 * @param {number} toUnix   seconds since epoch
 */
async function candles(symbol, resolution = "D", fromUnix, toUnix) {
  if (!symbol || !fromUnix || !toUnix) return {};
  return (
    (await getJson("/stock/candle", {
      symbol,
      resolution,
      from: fromUnix,
      to: toUnix,
    })) || {}
  );
}

/* ------------------ Small export helpers ------------------ */

// Convenience: Unix seconds for a JS Date / ms timestamp
const toUnixSec = (d) => Math.floor((d instanceof Date ? +d : d) / 1000);
// Convenience: Date N days ago
const daysAgo = (n) => new Date(Date.now() - n * 24 * 3600 * 1000);

module.exports = {
  // news & profiles
  companyNews,
  marketNews,
  companyProfile2,
  newsSentiment,
  // symbols & price utils
  listSymbols,
  symbolLookup,
  quote,
  candles,
  // helpers (optional use elsewhere)
  toISODate,
  toUnixSec,
  daysAgo,
};
