const POS = new Set(["beat","surge","record","acquire","growth","profit","strong","rise","expand","approve"]);
const NEG = new Set(["loss","fall","fraud","probe","lawsuit","bail","cut","miss","scandal","layoff","downgrade"]);
function scoreText(title, summary){
  const text = `${title||""} ${summary||""}`.toLowerCase();
  const toks = text.match(/[a-z]+/g) || [];
  let pos=0, neg=0;
  for(const w of toks){ if(POS.has(w)) pos++; if(NEG.has(w)) neg++; }
  const s = (pos+neg) ? (pos-neg)/(pos+neg) : 0; // -1..1
  const phrases = [...new Set(toks.filter(w=>POS.has(w)||NEG.has(w)))].slice(0,5);
  return { score: Math.max(-1, Math.min(1, s)), phrases };
}
module.exports = { scoreText };
