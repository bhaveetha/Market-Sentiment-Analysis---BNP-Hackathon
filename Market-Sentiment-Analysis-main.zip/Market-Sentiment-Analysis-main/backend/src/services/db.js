const mongoose = require("mongoose");
async function connect(uri){ await mongoose.connect(uri); console.log("Mongo connected"); }
module.exports = { connect };
