function normalizeArticles(raw, symbol){
  return raw.map(a => ({
    _id: String(a.id || a.url),
    symbol,
    source: a.source,
    title: a.headline || a.title,
    summary: a.summary || "",
    url: a.url,
    image: a.image,
    publishedAt: new Date((a.datetime||0)*1000)
  }));
}
const mapToFive = x => (x + 1) * 2.5; // [-1,1] -> [0,5]
module.exports = { normalizeArticles, mapToFive };
