const { marketNews } = require("../services/finnhub");
const Kv = require("../models/Kv");
const Article = require("../models/Article");
const { normalizeArticles, mapToFive } = require("../utils/normalize");
const { scoreText } = require("../services/sentiment");
const { buildAndSaveAllWindows } = require("../services/agg");

// crude symbol matching: look for $TICKER patterns in headline/summary
// (You can improve by using your Symbol collection for name matching)
function extractTickers(a) {
  const text = `${a.headline || a.title || ""} ${a.summary || ""}`;
  const m = text.match(/\$?[A-Z]{2,6}\b/g) || [];
  // strip '$' and common words like USA, CEO, etc.
  const bad = new Set(["USA","CEO","EPS","ETF","GDP","CPI","FED","USD","ECB","SEC","IPO"]);
  return [...new Set(m.map(x => x.replace("$","")).filter(t => t.length<=6 && !bad.has(t)))];
}

async function getMinId() {
  const row = await Kv.findOne({ key: "finnhub:news:minId" }).lean();
  return row?.value || 0;
}
async function setMinId(v) {
  await Kv.updateOne(
    { key: "finnhub:news:minId" },
    { $set: { value: v, updatedAt: new Date() } },
    { upsert: true }
  );
}

async function ingestMarketNews() {
  // read last minId
  let minId = await getMinId();

  // pull market feeds (one call each)
  const cats = ["general", "merger"];
  const feeds = await Promise.all(cats.map(c => marketNews(c, minId).catch(()=>[])));
  const merged = feeds.flat().sort((a,b)=>(a.id||0)-(b.id||0));

  if (!merged.length) return { upserts: 0, lastId: minId };

  let upserts = 0;
  let maxId = minId;

  for (const raw of merged) {
    if (!raw || !raw.headline) continue;

    const tickers = extractTickers(raw);
    if (!tickers.length) continue;

    // For each detected ticker, normalize/score/save as if it were company news
    for (const sym of tickers) {
      const norm = normalizeArticles([raw], sym);
      for (const a of norm) {
        const { score, phrases } = scoreText(a.title, a.summary);
        await Article.updateOne({ _id: a._id }, { ...a, score, phrases }, { upsert: true });
        upserts++;
      }
      // rebuild aggregates (7d/30d/1y) for that symbol
      try { await buildAndSaveAllWindows(sym, mapToFive); } catch(_) {}
    }

    if (raw.id && raw.id > maxId) maxId = raw.id;
  }

  if (maxId > minId) await setMinId(maxId);
  return { upserts, lastId: maxId };
}

// run loop
function startPulse({ intervalMs = 60000 } = {}) {
  let timer = null;
  const enabled = String(process.env.CRON_HOT || "true").toLowerCase() !== "false";

  if (!enabled) {
    console.log("[pulse] disabled via CRON_HOT=false");
    return () => {};
  }

  const tick = async () => {
    try {
      const { upserts, lastId } = await ingestMarketNews();
      if (upserts) console.log(`[pulse] upserts=${upserts} lastId=${lastId}`);
    } catch (e) {
      console.warn("[pulse] error:", e?.message || e);
    }
  };

  // start now, then repeat
  tick();
  timer = setInterval(tick, intervalMs);
  console.log(`[pulse] started (every ${intervalMs/1000}s)`);
  return () => clearInterval(timer);
}

module.exports = { startPulse };
