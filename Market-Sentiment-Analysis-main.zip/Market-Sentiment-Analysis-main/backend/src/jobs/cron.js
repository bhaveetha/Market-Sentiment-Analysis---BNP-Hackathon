// src/jobs/cron.js
const cron = require("node-cron");
const { companyNews, marketNews, companyProfile2 } = require("../services/finnhub");
const { normalizeArticles, mapToFive } = require("../utils/normalize");
const { scoreText } = require("../services/sentiment");
const Article = require("../models/Article");
const { buildAndSaveAllWindows } = require("../services/agg");

// Try to use DB-backed watchlist; fallback to .env WATCHLIST if missing/empty
let Watch = null;
try { Watch = require("../models/Watch"); } catch { /* optional model */ }

const DEFAULT_WATCH = (process.env.WATCHLIST || "AAPL,MSFT,NVDA,GOOGL,AMZN")
  .split(",").map(s => s.trim().toUpperCase()).filter(Boolean);

// small helper
const sleep = (ms) => new Promise(res => setTimeout(res, ms));

/**
 * Return the list of symbols to ingest:
 * - Prefer symbols from Watch collection (dynamic)
 * - Else fallback to .env WATCHLIST
 */
async function getWatchSymbols() {
  if (Watch) {
    const rows = await Watch.find().lean().catch(() => []);
    if (rows?.length) return rows.map(r => r.symbol);
  }
  return DEFAULT_WATCH;
}

/**
 * Ingest recent news for a symbol (last `days` days),
 * with fallback to Market News filtered by company name/ticker.
 */
async function ingestOnce(symbol, days = 2) {
  const to = new Date();
  const from = new Date(Date.now() - days * 24 * 3600 * 1000);
  const iso = d => d.toISOString().slice(0, 10);

  // 1) Company-specific news (best quality)
  let items = await companyNews(symbol, iso(from), iso(to));

  // 2) Fallback: Market News (general/merger) filtered by name/ticker
  if (!items || items.length === 0) {
    const profile = await companyProfile2(symbol);
    const name = (profile?.name || profile?.name2 || profile?.ticker || symbol || "").toLowerCase();
    const cats = ["general", "merger"];
    const feeds = await Promise.all(cats.map(c => marketNews(c)));
    const merged = feeds.flat();
    items = merged.filter(a => {
      const text = `${a.headline || a.title || ""} ${a.summary || ""}`.toLowerCase();
      return text.includes(symbol.toLowerCase()) || (name && text.includes(name));
    });
  }

  // 3) Normalize, score, upsert
  const norm = normalizeArticles(items || [], symbol);
  let upserts = 0;
  for (const a of norm) {
    const { score, phrases } = scoreText(a.title, a.summary);
    await Article.updateOne({ _id: a._id }, { ...a, score, phrases }, { upsert: true });
    upserts++;
  }

  return upserts;
}

/**
 * Ingest all watched symbols with a small stagger to avoid 429s, then
 * rebuild aggregates for 7d/30d/1y.
 */
async function runCycle() {
  const symbols = await getWatchSymbols();
  console.log(`[cron] symbols=${symbols.length} :: ${symbols.slice(0, 8).join(",")}${symbols.length > 8 ? "..." : ""}`);

  for (const s of symbols) {
    try {
      const inserted = await ingestOnce(s, 2); // last 48h (safe overlap)
      await buildAndSaveAllWindows(s, mapToFive); // recompute 7d, 30d, 1y
      console.log(`[cron] ${s}: upserts=${inserted} | aggregates updated`);
    } catch (e) {
      console.warn(`[cron] ${s} failed: ${e?.message || e}`);
    }
    // tiny pause to reduce Finnhub 429s
    await sleep(300);
  }

  console.log("[cron] ingest+score+aggregate cycle complete");
}

// Allow disabling cron from .env (CRON_ENABLED=false)
const enabled = String(process.env.CRON_ENABLED || "true").toLowerCase() !== "false";

// Schedule every 30 minutes
if (enabled) {
  cron.schedule("*/30 * * * *", async () => {
    try {
      await runCycle();
    } catch (e) {
      console.error("[cron] fatal:", e?.message || e);
    }
  });
  console.log("[cron] scheduled: every 30 minutes");
} else {
  console.log("[cron] disabled via CRON_ENABLED=false");
}

// Export for manual triggers/tests
module.exports = { ingestOnce, runCycle, getWatchSymbols };
