// src/server.js
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { connect } = require("./services/db");

// Routes
const sentiment = require("./routes/sentiment");
const news = require("./routes/news");
const wordcloud = require("./routes/wordcloud");
const reco = require("./routes/reco");
const ingest = require("./routes/ingest");
const overview = require("./routes/overview");
const symbols = require("./routes/symbols");      // symbol sync/search
const live = require("./routes/live");            // SSE Top-5 live
const timeseries = require("./routes/timeseries"); // ✅ NEW: daily avg sentiment series

// Optional: only if you created it
let watchlist;
try { watchlist = require("./routes/watchlist"); } catch { watchlist = null; }

// Hot market poller (real-time Finnhub /news incremental)
const { startPulse } = require("./jobs/marketPulse");

const app = express();

// --- middleware ---
const originsEnv = process.env.CORS_ORIGIN
  ? process.env.CORS_ORIGIN.split(",").map(s => s.trim())
  : null;
// If no explicit origins provided, allow all (no credentials)
const corsOptions = originsEnv && originsEnv.length
  ? { origin: originsEnv, credentials: true }
  : { origin: "*" };

app.use(cors(corsOptions));
app.use(express.json({ limit: "1mb" }));

// --- health ---
app.get("/", (_req, res) => res.redirect("/api/health"));
app.get("/api/health", (_req, res) => res.json({ ok: true }));

// --- routes ---
app.use("/api/sentiment", sentiment);
app.use("/api/news", news);
app.use("/api/wordcloud", wordcloud);
app.use("/api/reco", reco);
app.use("/api/ingest", ingest);
app.use("/api/overview", overview);
app.use("/api/symbols", symbols);
app.use("/api/live", live);               // SSE: /api/live/top5
app.use("/api/timeseries", timeseries);   // ✅ line chart data
if (watchlist) app.use("/api/watchlist", watchlist);

// ✅ Express v5-safe catch-all for unknown /api routes (no wildcards)
app.use("/api", (_req, res) => res.status(404).json({ error: "Not found" }));

// --- start ---
const PORT = process.env.PORT || 8000;
let server;
let stopPulse = null;

connect(process.env.MONGO_URI)
  .then(() => {
    // 30-min per-symbol cron (can be disabled with CRON_ENABLED=false)
    const cronEnabled = String(process.env.CRON_ENABLED || "true").toLowerCase() !== "false";
    if (cronEnabled) {
      try {
        require("./jobs/cron");
      } catch (e) {
        console.warn("Cron 30m not started:", e.message);
      }
    } else {
      console.log("Cron disabled via CRON_ENABLED=false");
    }

    // 🔥 Hot market pulse (real-time Finnhub /news incremental)
    // Enable/disable with CRON_HOT=true/false; interval via PULSE_MS (default 60000ms)
    const hotEnabled = String(process.env.CRON_HOT || "true").toLowerCase() !== "false";
    if (hotEnabled) {
      try {
        const intervalMs = parseInt(process.env.PULSE_MS || "60000", 10);
        stopPulse = startPulse({ intervalMs }); // returns a stop() function
        console.log(`[pulse] started: every ${intervalMs}ms`);
      } catch (e) {
        console.warn("Pulse not started:", e.message);
      }
    } else {
      console.log("Pulse disabled via CRON_HOT=false");
    }

    server = app.listen(PORT, () =>
      console.log(`API up at http://localhost:${PORT}`)
    );
  })
  .catch((err) => {
    console.error("Mongo connection failed:", err.message);
    process.exit(1);
  });

// --- graceful shutdown ---
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
process.on("unhandledRejection", (e) => console.error("unhandledRejection:", e));

async function shutdown() {
  try {
    console.log("Shutting down…");
    if (typeof stopPulse === "function") {
      try { await stopPulse(); } catch {}
    }
    if (server) {
      await new Promise((r) => server.close(r));
    }
  } finally {
    process.exit(0);
  }
}
