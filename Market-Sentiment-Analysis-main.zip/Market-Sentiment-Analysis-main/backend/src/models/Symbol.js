const mongoose = require("mongoose");

const SymbolSchema = new mongoose.Schema({
  symbol:   { type: String, required: true, unique: true, uppercase: true, trim: true },
  display:  { type: String, default: "" },   // company name
  currency: { type: String, default: "" },
  mic:      { type: String, default: "" },   // exchange MIC
  type:     { type: String, default: "" },   // Common Stock, ETF, etc.
  exchange: { type: String, default: "" },
  updatedAt:{ type: Date,   default: Date.now }
});

SymbolSchema.index({ symbol: 1 });
SymbolSchema.index({ display: "text" });

module.exports = mongoose.model("Symbol", SymbolSchema);
