const { Schema, model } = require("mongoose");
const AggregateSchema = new Schema({
  symbol: { type: String, index: true },
  window: { type: String },              // '7d' | '30d' | '1y'
  score0to5: Number,
  subs: { news: Number, social: Number, macro: Number },
  sparkline: [Number],
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });
AggregateSchema.index({ symbol:1, window:1 }, { unique:true });
module.exports = model("Aggregate", AggregateSchema);
