const mongoose = require("mongoose");

const KvSchema = new mongoose.Schema({
  key:   { type: String, required: true, unique: true },
  value: { type: mongoose.Schema.Types.Mixed, default: null },
  updatedAt: { type: Date, default: Date.now }
});
KvSchema.index({ key: 1 }, { unique: true });

module.exports = mongoose.model("Kv", KvSchema);
