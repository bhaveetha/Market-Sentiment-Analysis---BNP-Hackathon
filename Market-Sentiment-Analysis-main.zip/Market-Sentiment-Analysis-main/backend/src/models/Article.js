const { Schema, model } = require("mongoose");
const ArticleSchema = new Schema({
  _id: { type: String, required: true }, // id or url
  symbol: { type: String, index: true },
  source: String, title: String, summary: String,
  url: String, image: String,
  publishedAt: Date,
  score: Number,               // -1..1
  phrases: [String]
}, { timestamps: true });
module.exports = model("Article", ArticleSchema);
