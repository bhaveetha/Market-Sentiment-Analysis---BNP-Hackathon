const mongoose = require("mongoose");
const WatchSchema = new mongoose.Schema({
  symbol: { type: String, required: true, unique: true, uppercase: true, trim: true },
  alias:  { type: [String], default: [] },
  addedAt:{ type: Date, default: Date.now }
});
module.exports = mongoose.model("Watch", WatchSchema);
