// src/App.jsx
import { useEffect, useMemo, useState } from "react";
import "./app.css";
import DistPie from "./components/DistPie";
import LineSentiment from "./components/LineSentiment";
import MiniPie from "./components/MiniPie";
import SearchBar from "./components/SearchBar";
import WordCloud from "./components/WordCloud";
import { getOverview, getTimeseries, getWordcloud, quickIngestAll } from "./lib/api";

// Bright, high-contrast palette
const green = "#10b981"; // emerald-500
const red   = "#ef4444"; // red-500
const gray  = "#475569"; // slate-600
const blue  = "#2563eb"; // blue-600

export default function App() {
  const [win, setWin] = useState("3d");
  const [overview, setOverview] = useState(null);
  const [busy, setBusy] = useState(false);
  const [picked, setPicked] = useState([]);    // [] => Top 5; [SYM] => single company
  const [err, setErr] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshedAt, setRefreshedAt] = useState(null);

  // word cloud state (search only)
  const [wc, setWc] = useState(null);
  const [wcLoading, setWcLoading] = useState(false);

  // line chart state (search only)
  const [ts, setTs] = useState([]);
  const [tsLoading, setTsLoading] = useState(false);

  const isSearch = picked.length > 0;
  const searchSym = isSearch ? picked[0] : null;

  async function load() {
    try {
      setErr(null);
      setLoading(true);
      const data = await getOverview({
        // Home: [] -> Top 5 + 15 latest (all)
        // Search: [SYM] -> that company + 20 latest (selected)
        symbols: picked,
        window: win,
        limit: 5,
        feed: isSearch ? "selected" : "all",
        feedLimit: isSearch ? 20 : 15,
      });
      setOverview(data);
      setRefreshedAt(new Date());
    } catch (e) {
      console.error(e);
      setErr(e?.message || "Failed to load overview");
      setOverview({ symbols: [], companies: [], notifications: [] });
    } finally {
      setLoading(false);
    }
  }

  // word cloud loader (search only; last 15 days)
  useEffect(() => {
    let stop = false;
    const run = async () => {
      if (!isSearch || !searchSym) { setWc(null); return; }
      try {
        setWcLoading(true);
        const res = await getWordcloud(searchSym, { days: 15 });
        if (stop) return;
        const words =
          res?.words ||
          res?.terms ||   // legacy
          res?.tokens ||
          res?.items ||
          res?.data ||
          [];
        setWc(Array.isArray(words) ? words : []);
      } catch {
        if (!stop) setWc([]);
      } finally {
        if (!stop) setWcLoading(false);
      }
    };
    run();
    return () => { stop = true; };
  }, [isSearch, searchSym]);

  // line timeseries loader (search only; uses current window)
  useEffect(() => {
    let stop = false;
    const run = async () => {
      if (!isSearch || !searchSym) { setTs([]); return; }
      try {
        setTsLoading(true);
        const res = await getTimeseries(searchSym, { window: win });
        if (stop) return;
        setTs(Array.isArray(res?.series) ? res.series : []);
      } catch {
        if (!stop) setTs([]);
      } finally {
        if (!stop) setTsLoading(false);
      }
    };
    run();
    return () => { stop = true; };
  }, [isSearch, searchSym, win]);

  const handlePick = async (sym) => {
    if (!sym) { setPicked([]); return; }
    const val = sym.toUpperCase();
    setPicked([val]);
    try {
      setBusy(true);
      await quickIngestAll([val], 90);
      await load();
    } finally { setBusy(false); }
  };

  useEffect(() => { load(); /* eslint-disable-line */ }, []);
  useEffect(() => { load(); /* eslint-disable-line */ }, [win, picked]);

  const notifs = overview?.notifications || [];
  const companies = overview?.companies || [];
  const first = companies[0];

  // ---- Overview pies (Top-5 only) ----
  const aggCounts = useMemo(
    () =>
      notifs.reduce(
        (a, n) => {
          if (n.label === "Positive") a.pos++;
          else if (n.label === "Negative") a.neg++;
          else a.neu++;
          return a;
        },
        { pos: 0, neu: 0, neg: 0 }
      ),
    [notifs]
  );

  const posMap = useMemo(() => {
    const m = new Map();
    for (const n of notifs) if (n.label === "Positive") m.set(n.symbol, (m.get(n.symbol) || 0) + 1);
    return m;
  }, [notifs]);
  const topPos = [...posMap.entries()].sort((a,b)=>b[1]-a[1]).slice(0,6);
  const posLabels = topPos.map(([s])=>s);
  const posValues = topPos.map(([,v])=>v);
  const posColors = ["#10b981","#0ea5e9","#f59e0b","#a855f7","#22c55e","#ef4444"];

  const timeLabel = win.toUpperCase();

  const Card = ({ title, right, children, style }) => (
    <div style={{ ...styles.card, ...style }}>
      <div style={styles.cardHead}>
        <h3 style={styles.cardTitle}>{title}</h3>
        <div style={styles.cardRight}>{right}</div>
      </div>
      {children}
    </div>
  );

  const Badge = ({ text, tone = "neutral" }) => {
    const toneMap = {
      success: { bg: "rgba(16,185,129,.16)", color: green, br: "1px solid rgba(16,185,129,.28)" },
      danger:  { bg: "rgba(239,68,68,.16)",  color: red,   br: "1px solid rgba(239,68,68,.28)" },
      info:    { bg: "rgba(37,99,235,.16)",  color: blue,  br: "1px solid rgba(37,99,235,.28)" },
      neutral: { bg: "rgba(71,85,105,.14)",  color: gray,  br: "1px solid rgba(71,85,105,.24)" },
    };
    const t = toneMap[tone] || toneMap.neutral;
    return (
      <span style={{ fontWeight:700, fontSize:11, padding:"1px 7px",
                     borderRadius:999, background:t.bg, color:t.color, border:t.br }}>
        {text}
      </span>
    );
  };

  return (
    <div style={styles.page}>
      <header style={styles.header}>
        <div style={styles.brand}>
          <div style={styles.logoDot} />
          <div>
            <div style={styles.brandTitle}>Market Sentiment Dashboard</div>
            <div style={styles.brandSub}>Real-time news & social signals to inform Buy / Hold / Sell</div>
          </div>
        </div>

        <div style={styles.controls}>
          <SearchBar onPick={handlePick} />
          <select value={win} onChange={(e)=>setWin(e.target.value)} style={styles.select}>
            <option value="3d">3d</option><option value="7d">7d</option>
            <option value="30d">30d</option><option value="1y">1y</option>
          </select>
          <button onClick={()=>setPicked([])} style={styles.btnGhost}>Show Top 5</button>
          <button
            disabled={busy}
            onClick={async () => {
              try {
                setBusy(true);
                const syms = isSearch ? picked : (overview?.symbols || []);
                await quickIngestAll(syms, 365);
                await load();
              } finally { setBusy(false); }
            }}
            style={{ ...styles.btn, opacity: busy ? 0.65 : 1 }}
            title="Pull & score fresh news for current companies"
          >
            {busy ? "Ingesting…" : "Refresh"}
          </button>
        </div>
      </header>

      {err && <div style={styles.alert}><strong>⚠️</strong> {err}</div>}

      {loading ? (
        <div style={{ ...styles.skeleton, marginTop: 16 }}>
          <div style={styles.skelBar} /><div style={styles.skelRow}>
            <div style={styles.skelCard} /><div style={styles.skelCard} /></div>
        </div>
      ) : (
        <div style={styles.grid}>
          {/* LEFT: notifications */}
          <Card
            title={isSearch ? `Notifications — ${searchSym}` : "Latest Notifications"}
            right={
              <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                <Badge text={timeLabel} tone="info" />
                {refreshedAt && <span style={{ fontSize: 11, opacity:.65 }}>
                  Updated {refreshedAt.toLocaleTimeString()}
                </span>}
              </div>
            }
            style={{ gridColumn: "1 / 2" }}
          >
            <div style={{ marginTop: 6, display: "flex", flexDirection: "column", gap: 6 }}>
              {notifs.map(n => {
                const isPos = n.label === "Positive";
                const isNeg = n.label === "Negative";
                const color = isPos ? green : isNeg ? red : gray;
                return (
                  <div key={n.id} style={{ ...styles.notif, borderLeft: `2px solid ${color}` }}>
                    <div style={styles.notifTop}>
                      <Badge text={n.symbol} tone={isPos ? "success" : isNeg ? "danger" : "neutral"} />
                      <a href={n.url} target="_blank" rel="noreferrer" style={styles.notifTitle}>{n.title}</a>
                    </div>
                    <div style={styles.notifMeta}>
                      <span>{n.source}</span><span>•</span>
                      <span>{new Date(n.publishedAt).toLocaleString()}</span><span>•</span>
                      <span style={{ color, fontWeight: 700 }}>{n.label}</span>
                      <span style={{ opacity:.6 }}>({(n.score || 0).toFixed(2)})</span>
                    </div>
                  </div>
                );
              })}
              {!notifs.length && <div style={{ opacity:.75 }}>No notifications yet. Try “Refresh”.</div>}
            </div>
          </Card>

          {/* RIGHT column */}
          <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
            {isSearch ? (
              <>
                {/* Company summary */}
                <Card title={`Company — ${searchSym}`}>
                  {first ? (
                    <div style={styles.rankRow}>
                      <div>
                        <div style={styles.rankSym}>{first.symbol}</div>
                        <div style={styles.rankMeta}>
                          Overall {(first.score0to5 || 0).toFixed(1)} / 5 · <b>{first.stance}</b>
                        </div>
                        <div style={styles.rankMeta}>
                          +{Math.round(first.posPct * 100)}% / −{Math.round(first.negPct * 100)}%
                        </div>
                        {first.stance === "Hold" && (
                          <div style={{ fontSize: 12, marginTop: 4 }}>
                            Est: Buy {first?.pred?.buyInDays != null ? `in ${first.pred.buyInDays}d` : "—"} ·{" "}
                            Sell {first?.pred?.sellInDays != null ? `in ${first.pred.sellInDays}d` : "—"}
                          </div>
                        )}
                      </div>
                      <MiniPie pos={first.counts.pos} neu={first.counts.neu} neg={first.counts.neg} size={82} />
                      <div style={{ textAlign: "right", fontSize: 12 }}>
                        P:{first.counts.pos} N:{first.counts.neu} Neg:{first.counts.neg}
                      </div>
                    </div>
                  ) : <div style={{ opacity:.75 }}>No data for {searchSym} in this window.</div>}
                </Card>

                {/* Word cloud (search only; last 15 days) */}
                <Card
                  title="Word Cloud"
                  right={<span style={{ fontSize: 12, opacity:.7 }}>15D</span>}
                >
                  {wcLoading ? (
                    <div style={{ opacity:.7 }}>Building cloud…</div>
                  ) : (
                    <WordCloud items={wc || []} />
                  )}
                </Card>

                {/* ✅ Line chart just below the word cloud (search only) */}
                <Card
                  title="Sentiment Trend"
                  right={<span style={{ fontSize: 12, opacity:.7 }}>{timeLabel}</span>}
                >
                  {tsLoading ? (
                    <div style={{ opacity:.7 }}>Loading trend…</div>
                  ) : (
                    <LineSentiment series={ts || []} />
                  )}
                </Card>
              </>
            ) : (
              <>
                {/* Top-5 ranking */}
                <Card title="Company Ranking (Top 5)" right={<span style={{ fontSize: 12, opacity:.7 }}>Sorted by net positive</span>}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {companies.map(c => (
                      <div key={c.symbol} style={styles.rankRow}>
                        <div>
                          <div style={styles.rankSym}>{c.symbol}</div>
                          <div style={styles.rankMeta}>Overall {(c.score0to5 || 0).toFixed(1)} / 5 · <b>{c.stance}</b></div>
                          <div style={styles.rankMeta}>+{Math.round(c.posPct * 100)}% / −{Math.round(c.negPct * 100)}%</div>
                          {c.stance === "Hold" && (
                            <div style={{ fontSize: 12, marginTop: 4 }}>
                              Est: Buy {c?.pred?.buyInDays != null ? `in ${c.pred.buyInDays}d` : "—"} ·{" "}
                              Sell {c?.pred?.sellInDays != null ? `in ${c.pred.sellInDays}d` : "—"}
                            </div>
                          )}
                        </div>
                        <MiniPie pos={c.counts.pos} neu={c.counts.neu} neg={c.counts.neg} size={82} />
                        <div style={{ textAlign: "right", fontSize: 12 }}>
                          P:{c.counts.pos} N:{c.counts.neu} Neg:{c.counts.neg}
                        </div>
                      </div>
                    ))}
                    {!companies.length && <div style={{ opacity:.75 }}>Nothing yet. Try “Show Top 5”.</div>}
                  </div>
                </Card>

                {/* Overview pies */}
                <Card title="Overview">
                  <div style={styles.pies}>
                    <DistPie
                      title="Market Sentiment Split"
                      labels={["Positive","Neutral","Negative"]}
                      values={[aggCounts.pos, aggCounts.neu, aggCounts.neg]}
                      colors={["#10b981","#94a3b8","#ef4444"]}
                    />
                    <DistPie
                      title="Top Positive by Company"
                      labels={posLabels}
                      values={posValues}
                      colors={posColors}
                    />
                  </div>
                </Card>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------- styles ---------------- */
const styles = {
  page: { maxWidth: 1240, margin: "0 auto", padding: "16px" },

  header: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    gap: 12, padding: "10px 14px",
    border: "1px solid #e5e7eb", borderRadius: 12, background: "#ffffff", color: "#0f172a",
    boxShadow: "0 1px 0 rgba(0,0,0,.04)"
  },
  brand: { display: "flex", alignItems: "center", gap: 10 },
  logoDot: { width: 12, height: 12, borderRadius: 999, background: "#2563eb", boxShadow: "0 0 0 3px rgba(37,99,235,.15)" },
  brandTitle: { fontWeight: 800, letterSpacing: .2, fontSize: 16, marginBottom: 2 },
  brandSub: { fontSize: 12, opacity: .65 },

  controls: { display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" },
  select: { padding: 8, borderRadius: 8, border: "1px solid #e5e7eb" },
  btn: {
    padding: "8px 12px", borderRadius: 8, border: "1px solid #dbeafe",
    background: "#eef2ff", color: "#1e3a8a", fontWeight: 600, cursor: "pointer"
  },
  btnGhost: {
    padding: "8px 12px", borderRadius: 8, border: "1px solid #e5e7eb",
    background: "#fff", color: "#111827", fontWeight: 600, cursor: "pointer"
  },

  alert: { marginTop: 12, padding: 10, border: "1px solid #fecaca", background: "#fef2f2", borderRadius: 8, color: "#991b1b" },

  grid: { display: "grid", gridTemplateColumns: "1fr 440px", gap: 16, marginTop: 16 },

  card: { border: "1px solid #e5e7eb", borderRadius: 12, padding: 12, background: "#fff", color: "#0f172a" },
  cardHead: { display: "flex", justifyContent: "space-between", alignItems: "baseline" },
  cardTitle: { margin: 0, fontSize: 16 },
  cardRight: { fontSize: 12, opacity: .7 },

  notif: { borderRadius: 10, padding: 8, border: "1px solid #f3f4f6", background: "#ffffff" },
  notifTop: { display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", marginBottom: 2 },
  notifTitle: {
    fontWeight: 700, color: "#0f172a", textDecoration: "none",
    fontSize: 13, lineHeight: 1.28,
    display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical",
    overflow: "hidden"
  },
  notifMeta: { fontSize: 11, opacity: 0.78, display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" },

  rankRow: {
    display: "grid", gridTemplateColumns: "1fr auto auto", alignItems: "center",
    gap: 10, border: "1px solid #f3f4f6", borderRadius: 10, padding: 10, background: "#ffffff"
  },
  rankSym: { fontWeight: 800, fontSize: 16 },
  rankMeta: { fontSize: 12, opacity: .8 },

  pies: { display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(260px,1fr))", gap:16 },

  skeleton: { width: "100%" },
  skelBar: { height: 16, width: 220, background: "#f3f4f6", borderRadius: 8 },
  skelRow: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 12 },
  skelCard: { height: 160, background: "#f3f4f6", borderRadius: 12 },
};
