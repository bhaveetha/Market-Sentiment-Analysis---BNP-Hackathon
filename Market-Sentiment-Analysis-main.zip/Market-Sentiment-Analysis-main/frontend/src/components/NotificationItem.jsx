
function timeAgo(ts){
  const d = new Date(ts);
  const diff = (Date.now() - d.getTime()) / 1000;
  if (diff < 60) return `${Math.floor(diff)}s ago`;
  if (diff < 3600) return `${Math.floor(diff/60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
  return d.toLocaleString();
}

export default function NotificationItem({ n }) {
  const isPos = n.label === "Positive";
  const isNeg = n.label === "Negative";
  const cls = isPos ? "notif pos" : isNeg ? "notif neg" : "notif neu";

  return (
    <div className={cls}>
      <div className="row">
        <span className="symbol-chip">{n.symbol}</span>
        <a className="title" href={n.url} target="_blank" rel="noreferrer">
          {n.title}
        </a>
        {isPos && <span className="badge"><span className="dot pos" /> Positive</span>}
        {isNeg && <span className="badge"><span className="dot neg" /> Negative</span>}
        {!isPos && !isNeg && <span className="badge"><span className="dot neu" /> Neutral</span>}
      </div>
      <div className="meta">
        {n.source} · {timeAgo(n.publishedAt)} · <strong style={{ color:isPos ? "#22c55e" : isNeg ? "#ef4444" : "#94a3b8" }}>
          {n.label}
        </strong> ({(n.score || 0).toFixed(2)})
      </div>
    </div>
  );
}
