// src/components/WordCloud.jsx
import { useMemo } from "react";

// High-contrast palette for tags
const PALETTE = [
  "#1d4ed8", "#0ea5e9", "#16a34a", "#f59e0b", "#ef4444",
  "#7c3aed", "#059669", "#dc2626", "#2563eb", "#a855f7",
];

// small helper: hex -> rgba string with alpha
function hexToRgba(hex, a = 0.12) {
  const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!m) return `rgba(0,0,0,${a})`;
  const r = parseInt(m[1], 16);
  const g = parseInt(m[2], 16);
  const b = parseInt(m[3], 16);
  return `rgba(${r},${g},${b},${a})`;
}

export default function WordCloud({
  items = [],
  minFont = 12,
  maxFont = 28,     // slightly smaller to avoid “blobby” look
  maxItems = 36,    // fewer items = cleaner
  className = "",
}) {
  // Normalize shapes (string or object), then sort & cap
  const terms = useMemo(() => {
    const raw = Array.isArray(items) ? items : [];
    const mapped = raw.map((t) => {
      if (typeof t === "string") return { text: t, value: 1 };
      const text = t.text || t.word || t.term || t.token || t.key || "";
      const value = Number(t.value ?? t.count ?? t.weight ?? t.score ?? 0) || 0;
      return { text: String(text), value };
    }).filter((t) => t.text);
    return mapped.sort((a,b)=>b.value - a.value).slice(0, maxItems);
  }, [items, maxItems]);

  // value -> font scale
  const [minV, maxV] = useMemo(() => {
    if (!terms.length) return [0, 0];
    let mi = Infinity, ma = -Infinity;
    for (const t of terms) { if (t.value < mi) mi = t.value; if (t.value > ma) ma = t.value; }
    if (!Number.isFinite(mi) || !Number.isFinite(ma)) return [0,0];
    return [mi, ma];
  }, [terms]);

  const scale = (v) => {
    if (maxV === minV) return Math.round((minFont + maxFont) / 2);
    const r = (v - minV) / (maxV - minV);
    return Math.round(minFont + r * (maxFont - minFont));
  };

  // gentle random for tiny rotation & opacity (stable per word)
  const jitter = (seed) => {
    // deterministic-ish from string
    let h = 0; for (let i=0;i<seed.length;i++) h = (h*31 + seed.charCodeAt(i)) | 0;
    const rand = (n) => (((Math.sin(h += 0.1) + 1) / 2) * n);
    const rotate = Math.round(rand(10) - 5);       // -5..+5 deg
    const op = 0.85 + rand(0.15);                  // 0.85..1.0
    return { rotate, op };
  };

  return (
    <div
      className={className}
      style={{
        border: "1px solid #e5e7eb",
        borderRadius: 12,
        padding: 10,
        background: "#fff",
      }}
      aria-label="Keyword word cloud"
      role="img"
    >
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 6,
          lineHeight: 1.15,
          alignItems: "flex-start",
        }}
      >
        {terms.length === 0 ? (
          <div style={{ opacity: 0.7, fontSize: 13 }}>No keywords yet.</div>
        ) : (
          terms.map((t, i) => {
            const size = scale(t.value);
            const color = PALETTE[i % PALETTE.length];
            const bg = hexToRgba(color, 0.12);
            const { rotate, op } = jitter(t.text);
            return (
              <span
                key={`${t.text}-${i}`}
                title={`${t.text} (${t.value})`}
                style={{
                  fontSize: size,
                  fontWeight: 800,
                  color,
                  background: bg,
                  border: `1px solid ${hexToRgba(color, 0.2)}`,
                  borderRadius: 999,
                  padding: "4px 8px",
                  display: "inline-block",
                  transform: `rotate(${rotate}deg)`,
                  opacity: op,
                  // keep layout tidy
                  maxWidth: 180,
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  // micro interaction
                  transition: "transform 100ms ease, opacity 120ms ease",
                  cursor: "default",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.transform = `rotate(${rotate}deg) scale(1.04)`)}
                onMouseLeave={(e) => (e.currentTarget.style.transform = `rotate(${rotate}deg) scale(1.0)`)}
              >
                {t.text}
              </span>
            );
          })
        )}
      </div>
    </div>
  );
}
