// src/components/LineSentiment.jsx
import { CategoryScale, Chart as ChartJS, Filler, Legend, LinearScale, LineElement, PointElement, Tooltip } from "chart.js";
import { Line } from "react-chartjs-2";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend, Filler);

export default function LineSentiment({ series = [], height = 220 }) {
  const labels = series.map((d) => d.date);
  const values = series.map((d) => Number(d.avgScore) || 0);

  const data = {
    labels,
    datasets: [
      {
        label: "Avg Sentiment (daily)",
        data: values,
        borderColor: "#2563eb",
        backgroundColor: "rgba(37,99,235,.12)",
        tension: 0.35,
        pointRadius: 2,
        pointHoverRadius: 4,
        fill: true,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        callbacks: {
          label: (ctx) => `Avg: ${Number(ctx.parsed.y).toFixed(2)}`,
          afterLabel: (ctx) => {
            const i = ctx.dataIndex;
            const row = series[i] || {};
            const { pos = 0, neu = 0, neg = 0, total = 0 } = row;
            return ` P:${pos} N:${neu} Neg:${neg}  Total:${total}`;
          },
        },
      },
    },
    scales: {
      x: { grid: { display: false } },
      y: {
        suggestedMin: -1,
        suggestedMax: 1,
        ticks: { stepSize: 0.5 },
        grid: { color: "rgba(0,0,0,.06)" },
      },
    },
  };

  if (!series?.length) {
    return <div style={{ opacity: 0.7, padding: 8 }}>No sentiment trend yet.</div>;
  }

  return (
    <div style={{ height }}>
      <Line data={data} options={options} />
    </div>
  );
}
