// src/components/DistPie.jsx
import { ArcElement, Chart as ChartJS, Legend, Tooltip } from "chart.js";
import { Doughnut } from "react-chartjs-2";
ChartJS.register(ArcElement, Tooltip, Legend);

// Bright, accessible default palette
const DEFAULT_COLORS = ["#10b981", "#94a3b8", "#ef4444", "#2563eb", "#f59e0b", "#a855f7"];

export default function DistPie({
  title,
  labels = [],
  values = [],
  colors = DEFAULT_COLORS,
  size,                 // optional px; else responsive square
  className = "",
  centerText,           // optional string; if omitted shows total (or "—" when empty)
  showLegend = true,
  cutout = "60%",
}) {
  const safeValues = (values || []).map(v => Number(v) || 0);
  const total = safeValues.reduce((a, b) => a + b, 0);

  const data = {
    labels,
    datasets: [
      {
        data: total === 0 ? [1] : safeValues,         // neutral placeholder if empty
        backgroundColor: total === 0 ? ["#e5e7eb"] : colors,
        borderWidth: 0,
        hoverOffset: 4,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    cutout,
    plugins: {
      legend: {
        display: showLegend,
        position: "bottom",
        labels: { color: "#0f172a", boxWidth: 12, font: { size: 11 }, padding: 8 },
      },
      tooltip: {
        enabled: true,
        callbacks: {
          label: (ctx) => {
            const raw = Number(ctx.parsed) || 0;
            const ds = ctx.dataset?.data || [];
            const sum = ds.reduce((a, b) => a + (Number(b) || 0), 0);
            const pct = sum ? Math.round((raw / sum) * 100) : 0;
            return `${ctx.label ?? ""}: ${raw}${sum ? ` (${pct}%)` : ""}`;
          },
        },
      },
    },
    layout: { padding: { top: 4, bottom: 4, left: 4, right: 4 } },
  };

  // Center label (no extra deps)
  const centerLabelPlugin = {
    id: "centerLabel",
    afterDraw(chart) {
      const { ctx, chartArea } = chart || {};
      if (!ctx || !chartArea) return;

      const text =
        total === 0 ? "—" : (typeof centerText === "string" ? centerText : String(total));

      ctx.save();
      ctx.font = "700 13px system-ui, -apple-system, Segoe UI, Roboto, Arial";
      ctx.fillStyle = "#0f172a";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const { left, right, top, bottom } = chartArea;
      ctx.fillText(text, (left + right) / 2, (top + bottom) / 2);
      ctx.restore();
    },
  };

  const wrapperStyle = size
    ? { position: "relative", width: size, height: size, margin: "0 auto" }
    : { position: "relative", width: "100%", maxWidth: 340, aspectRatio: "1 / 1", margin: "0 auto", overflow: "hidden" };

  return (
    <div
      className={className}
      style={{ border: "1px solid #eee", borderRadius: 12, padding: 12, background: "#fff", color: "#0f172a" }}
      aria-label={title}
    >
      {title && <div style={{ fontSize: 12, opacity: 0.75, marginBottom: 6 }}>{title}</div>}
      <div style={wrapperStyle}>
        <Doughnut data={data} options={options} plugins={[centerLabelPlugin]} />
      </div>
    </div>
  );
}
