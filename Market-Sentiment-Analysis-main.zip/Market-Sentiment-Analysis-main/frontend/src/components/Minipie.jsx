// src/components/MiniPie.jsx
import { ArcElement, Chart as ChartJS, Tooltip } from "chart.js";
import { Pie } from "react-chartjs-2";
ChartJS.register(ArcElement, Tooltip);

// vivid, accessible slices
const POS = "#10b981"; // emerald-500
const NEU = "#94a3b8"; // slate-400
const NEG = "#ef4444"; // red-500

export default function MiniPie({
  pos = 0,
  neu = 0,
  neg = 0,
  size = 76,        // compact by default
  className = "",
  showCenter = true // show total in the center
}) {
  const values = [Number(pos) || 0, Number(neu) || 0, Number(neg) || 0];
  const total = values.reduce((a, b) => a + b, 0);
  const allZero = total === 0;

  const data = {
    labels: ["Positive", "Neutral", "Negative"],
    datasets: [
      {
        data: allZero ? [1, 0, 0] : values, // neutral placeholder if empty
        backgroundColor: allZero ? ["#e5e7eb", "#e5e7eb", "#e5e7eb"] : [POS, NEU, NEG],
        borderWidth: 0,
        hoverOffset: 3,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        enabled: true,
        callbacks: {
          label: (ctx) => {
            const raw = Number(ctx.parsed) || 0;
            const ds = ctx.dataset?.data || [];
            const sum = ds.reduce((a, b) => a + (Number(b) || 0), 0);
            const pct = sum ? Math.round((raw / sum) * 100) : 0;
            return `${ctx.label}: ${raw}${sum ? ` (${pct}%)` : ""}`;
          },
        },
      },
    },
    animation: { duration: 220 },
  };

  // center total (or em dash when empty)
  const centerLabel = {
    id: "miniCenterLabel",
    afterDraw(chart) {
      if (!showCenter) return;
      const { ctx, chartArea } = chart || {};
      if (!ctx || !chartArea) return;
      const txt = allZero ? "—" : String(total);
      ctx.save();
      ctx.font = "700 11px system-ui, -apple-system, Segoe UI, Roboto, Arial";
      ctx.fillStyle = "#0f172a"; // slate-900
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const { left, right, top, bottom } = chartArea;
      ctx.fillText(txt, (left + right) / 2, (top + bottom) / 2);
      ctx.restore();
    },
  };

  return (
    <div
      className={className}
      style={{ width: size, height: size }}
      role="img"
      aria-label={`Sentiment mini chart. Positive ${values[0]}, Neutral ${values[1]}, Negative ${values[2]}.`}
    >
      <Pie data={data} options={options} plugins={[centerLabel]} />
    </div>
  );
}
