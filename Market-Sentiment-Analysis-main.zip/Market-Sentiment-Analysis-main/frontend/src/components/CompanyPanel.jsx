import { ArcElement, Chart as ChartJS, Legend, Tooltip } from "chart.js";
import { useMemo } from "react";
import { Pie } from "react-chartjs-2";
ChartJS.register(ArcElement, Tooltip, Legend);

// simple thresholds for classification
const POS_THRESH = 0.05;
const NEG_THRESH = -0.05;

export default function CompanyPanel({ symbol, win, sent, news }) {
  const { pos, neg, neu } = useMemo(() => {
    const items = news?.items || [];
    let pos = 0, neg = 0, neu = 0;
    for (const it of items) {
      const s = Number(it.score || 0);
      if (s >= POS_THRESH) pos++;
      else if (s <= NEG_THRESH) neg++;
      else neu++;
    }
    return { pos, neg, neu };
  }, [news]);

  const pieData = useMemo(() => ({
    labels: ["Positive", "Neutral", "Negative"],
    datasets: [{
      data: [pos, neu, neg],
      backgroundColor: ["#16a34a", "#9ca3af", "#dc2626"],     // green, gray, red
      borderColor: ["#16a34a", "#9ca3af", "#dc2626"],
      borderWidth: 1
    }]
  }), [pos, neu, neg]);

  return (
    <div style={{border:"1px solid #e5e7eb", borderRadius:12, padding:16, marginTop:16}}>
      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
        <h3 style={{margin:0}}>{symbol} • {win.toUpperCase()}</h3>
        <div style={{fontSize:14, opacity:.7}}>
          Overall: <b>{(sent?.score0to5 ?? 0).toFixed(1)} / 5</b> &nbsp;|&nbsp;
          News: {(sent?.subs?.news ?? 0).toFixed(2)} &nbsp;|&nbsp;
          Social: {(sent?.subs?.social ?? 0).toFixed(2)} &nbsp;|&nbsp;
          Macro: {(sent?.subs?.macro ?? 0).toFixed(2)}
        </div>
      </div>

      {/* content grid */}
      <div style={{display:"grid", gridTemplateColumns:"320px 1fr", gap:16, marginTop:12}}>
        {/* Pie chart */}
        <div style={{border:"1px solid #eee", borderRadius:10, padding:12}}>
          <div style={{fontSize:12, opacity:.7, marginBottom:8}}>Sentiment split</div>
          <Pie data={pieData} />
          <div style={{fontSize:12, opacity:.7, marginTop:8}}>
            Positive: {pos} • Neutral: {neu} • Negative: {neg}
          </div>
        </div>

        {/* Notifications list */}
        <div style={{border:"1px solid #eee", borderRadius:10, padding:12}}>
          <div style={{fontSize:12, opacity:.7, marginBottom:8}}>Notifications</div>
          <div style={{display:"flex", flexDirection:"column", gap:8, maxHeight:360, overflow:"auto"}}>
            {(news?.items || []).map(item => {
              const s = Number(item.score || 0);
              const isPos = s >= POS_THRESH, isNeg = s <= NEG_THRESH;
              const borderColor = isPos ? "#16a34a" : isNeg ? "#dc2626" : "#9ca3af";
              const badgeStyle = {
                display:"inline-block", padding:"2px 8px", borderRadius:999, fontSize:12,
                background: isPos ? "rgba(22,163,74,.1)" : isNeg ? "rgba(220,38,38,.1)" : "rgba(156,163,175,.15)",
                color: isPos ? "#166534" : isNeg ? "#7f1d1d" : "#374151",
                border:`1px solid ${borderColor}`
              };
              return (
                <div key={item.id} style={{borderLeft:`4px solid ${borderColor}`, paddingLeft:12}}>
                  <a href={item.url} target="_blank" rel="noreferrer" style={{fontWeight:600, textDecoration:"none", color:"#111827"}}>
                    {item.title}
                  </a>
                  <div style={{fontSize:12, opacity:.7}}>
                    {item.source} · {new Date(item.publishedAt).toLocaleString()}
                  </div>
                  <div style={{marginTop:4}}>
                    <span style={badgeStyle}>
                      {isPos ? "Positive" : isNeg ? "Negative" : "Neutral"} · {s.toFixed(2)}
                    </span>
                    {item.why?.length ? (
                      <span style={{fontSize:12, opacity:.7, marginLeft:8}}>Why: {item.why.join(", ")}</span>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
