// src/components/SearchBar.jsx
import { useEffect, useRef, useState } from "react";
import { searchSymbols } from "../lib/api";

/** Symbol typeahead + manual search button + Enter + arrow-key support */
export default function SearchBar({ onPick }) {
  const [q, setQ] = useState("");
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(false);
  const [hi, setHi] = useState(-1); // highlighted index for keyboard nav
  const boxRef = useRef(null);
  const listRef = useRef(null);

  // match App.jsx "btnGhost" styling
  const btnGhostStyle = {
    padding: "8px 12px",
    borderRadius: 8,
    border: "1px solid #e5e7eb",
    background: "#fff",
    color: "#111827",
    fontWeight: 600,
    cursor: "pointer",
  };

  const choose = (sym) => {
    const val = (sym || "").trim().toUpperCase();
    onPick?.(val || null);
    if (val) setQ(val);
    setOpen(false);
    setHi(-1);
  };

  // close dropdown when clicking outside
  useEffect(() => {
    const onClick = (e) => {
      if (!boxRef.current?.contains(e.target)) setOpen(false);
    };
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  // debounced search
  useEffect(() => {
    let active = true;
    const run = async () => {
      if (!q || q.length < 1) {
        setItems([]);
        setOpen(false);
        setHi(-1);
        return;
      }
      setPending(true);
      try {
        const res = await searchSymbols(q, "US");
        if (!active) return;
        const list = (res?.items || res?.result || [])
          .slice(0, 10)
          .map((r) => ({
            symbol: r.symbol || r.displaySymbol || r.ticker,
            name: r.description || r.name || r.symbol,
            type: r.type || "",
          }))
          .filter((r) => r.symbol);
        setItems(list);
        setOpen(!!list.length);
        setHi(list.length ? 0 : -1);
      } catch {
        if (!active) return;
        setItems([]);
        setOpen(false);
        setHi(-1);
      } finally {
        if (active) setPending(false);
      }
    };
    const t = setTimeout(run, 220);
    return () => {
      active = false;
      clearTimeout(t);
    };
  }, [q]);

  // keyboard control on input
  const onKeyDown = (e) => {
    if (!open && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
      setOpen(true);
      return;
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setHi((i) => (items.length ? (i + 1) % items.length : -1));
      scrollIntoView((hi + 1) % items.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setHi((i) => (items.length ? (i - 1 + items.length) % items.length : -1));
      scrollIntoView((hi - 1 + items.length) % items.length);
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (open && hi >= 0 && items[hi]) choose(items[hi].symbol);
      else choose(q);
    } else if (e.key === "Escape") {
      setOpen(false);
      setHi(-1);
    }
  };

  const scrollIntoView = (idx) => {
    const el = listRef.current?.querySelector(`[data-idx="${idx}"]`);
    if (el?.scrollIntoView) el.scrollIntoView({ block: "nearest" });
  };

  return (
    <div
      ref={boxRef}
      style={{ position: "relative", display: "flex", gap: 8, alignItems: "center" }}
      role="search"
      aria-label="Symbol search"
    >
      <div style={{ position: "relative" }}>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder="Search ticker (e.g., AAPL)…"
          style={{
            padding: 8,
            minWidth: 320,
            borderRadius: 10,
            border: "1px solid #e5e7eb",
            outline: "none",
          }}
          onFocus={() => {
            if (items.length) setOpen(true);
          }}
          aria-autocomplete="list"
          aria-expanded={open}
          aria-controls="symbol-suggestions"
        />
        {open && (
          <div
            id="symbol-suggestions"
            ref={listRef}
            style={{
              position: "absolute",
              top: "110%",
              left: 0,
              right: 0,
              zIndex: 20,
              background: "#fff",
              border: "1px solid #e5e7eb",
              borderRadius: 10,
              padding: 6,
              maxHeight: 280,
              overflowY: "auto",
              boxShadow: "0 10px 30px rgba(0,0,0,.12)",
            }}
            role="listbox"
          >
            {items.length === 0 && !pending && (
              <div
                style={{
                  padding: "8px 10px",
                  fontSize: 12,
                  color: "#64748b",
                }}
              >
                No matches
              </div>
            )}
            {items.map((it, idx) => {
              const active = idx === hi;
              return (
                <div
                  key={it.symbol}
                  data-idx={idx}
                  role="option"
                  aria-selected={active}
                  onMouseEnter={() => setHi(idx)}
                  onMouseDown={(e) => e.preventDefault()} // prevent input blur before click
                  onClick={() => choose(it.symbol)}
                  style={{
                    padding: "8px 10px",
                    borderRadius: 8,
                    cursor: "pointer",
                    background: active ? "#f3f4f6" : "transparent",
                  }}
                >
                  <b>{it.symbol}</b>{" "}
                  <span style={{ opacity: 0.7 }}>— {it.name}</span>
                </div>
              );
            })}
            <div
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => choose(null)}
              style={{
                padding: "6px 10px",
                fontSize: 12,
                opacity: 0.7,
                cursor: "pointer",
                borderTop: "1px solid #f1f5f9",
                marginTop: 6,
              }}
            >
              Clear (show Top 5)
            </div>
          </div>
        )}
      </div>

      <button
        onClick={() => choose(q)}
        disabled={!q.trim() || pending}
        style={{
          ...btnGhostStyle,
          opacity: !q.trim() || pending ? 0.6 : 1,
          cursor: !q.trim() || pending ? "not-allowed" : "pointer",
        }}
        title="Search by ticker"
      >
        {pending ? "Searching…" : "Search"}
      </button>
    </div>
  );
}
